---
name: bee-resource-list
description: "This skill should be used when generating a new resource list page (index.vue) for the Bee Kube Kubernetes management platform. It produces list pages that follow the project's standardized three-column flex layout pattern with full CRUD, search, pagination, selection, and permission support. Trigger this skill when the user asks to create a list page for a Kubernetes resource such as Deployment, StatefulSet, Service, Node, Namespace, ConfigMap, Secret, or a platform resource such as User, Role, Menu."
---

# Bee Kube Resource List Page Generator

## 1. Purpose

Generate a complete, production-ready resource list page (`index.vue`) for the Bee Kube platform.
The generated code adheres strictly to the project's coding conventions: three-column flex layout,
standardized script sections, Element Plus / Bee component library usage, permission-based action
controls, and SCSS styling with project variables.

## 2. Workflow

### Step 1: Collect Resource Parameters

Before generating any code, collect the following information from the user (or infer from context):

| Parameter | Description | Example |
|---|---|---|
| `domain` | Top-level domain: `kubernetes` or `platform` | `kubernetes` |
| `module` | Sub-module path under the domain | `workload` |
| `ResourceName` | PascalCase resource name | `Deployment`, `StatefulSet` |
| `resourceName` | camelCase resource name | `deployment`, `statefulSet` |
| `routeName` | Kebab-case route key used in `router.push({ name })` | `kubernetes:workload:deployment` |
| `apiPrefix` | API URL prefix | `/kubernetes/clusters/${clusterId}/workload/deployments` |
| `hasClusterId` | Whether routes/APIs carry `:clusterId` param (true for K8s resources, false for platform) | `true` |
| `infoCellComponent` | Which Bee cell component to use for the first column | `BeeWorkloadInfoCell` |
| `infoCellProps` | Props map for the info cell (e.g., `uid`, `name`, `description`) | `{ uid: "id", name: "name", description: "description" }` |
| `searchFields` | Extra search filter fields beyond the default name/id search | `[{ label: '状态', prop: 'status', component: 'BeeSelect', options: 'STATUS_OPTIONS' }]` |
| `extraColumns` | Columns beyond the standard set (info, common, status, audit, action) | `[{ prop: 'k8sVersion', label: 'K8s 版本', component: 'BeeTableCommonCell', props: { text: 'row.k8sVersion' } }]` |
| `rowActions` | Row-level actions | `['view', 'edit', 'delete', 'restart', 'scale']` |
| `batchActions` | Batch operations | `['delete', 'export']` |
| `permissionPrefix` | Permission string prefix | `kubernetes:workload:deployment` |
| `pageTitle` | Page title and description | `{ title: 'Deployment', description: '管理无状态应用工作负载' }` |
| `createRoute` | Route name for the create page | `kubernetes:workload:deployment:create` |
| `editRoute` | Route name for the edit page (usually same as create but with query) | `kubernetes:workload:deployment:create` |
| `detailRoute` | Route name for the detail page | `kubernetes:workload:deployment:detail` |

If the user does not provide a parameter, infer reasonable defaults based on the resource name and project conventions. For Kubernetes resources, always assume `hasClusterId: true` and `apiPrefix` includes `${clusterId}`.

### Step 2: Verify Related Files

Before writing the list page, check that the following prerequisite files exist (create them if they don't):

1. **Types file**: `src/types/{{domain}}/{{module}}/{{resourceName}}.ts`
   - Must define: `{{ResourceName}}ListVo extends BaseEntity`, `{{ResourceName}}QueryForm extends PageForm`
2. **API file**: `src/api/{{domain}}/{{module}}/{{resourceName}}.ts`
   - Must export: `get{{ResourceName}}Page`, `delete{{ResourceName}}`, `delete{{ResourceName}}s`
3. **Mock file** (optional): `src/mock/{{domain}}/{{module}}/{{resourceName}}.ts`
4. **Route entry**: Ensure routes for index/create/edit/detail exist in `src/router/{{domain}}/{{module}}.ts`
5. **Config entry**: If the resource icon/name mapping is in `src/config/kubernetes.ts`, ensure it is registered

If any required file is missing, generate it following the project's types/api/mock coding conventions.

### Step 3: Generate the List Page

Use the template in `assets/index.vue.template` as the base. Replace all `{{placeholder}}` tokens
with the collected parameters. Follow the substitutions table in the template file's header comment.

Key generation rules:
- **Template**: Three-card layout with `BeePage` → `BeeCard`(header) + `BeeCard`(body).
- **Script sections** (in order): Composables & Route → Reactive State → Options → Data Loading → Search & Reset → Selection → CRUD: Create/Edit/View → CRUD: Delete → Row Actions → Lifecycle.
- **Permission caching**: Pre-compute `perm` object at script top-level using `hasPermission()`.
- **Search mapping**: The `searchKey` variable maps to multiple fields (id + name) via `handleSearch`.
- **Pagination**: Separate `pagination` (ref) and `queryForm` (reactive). Merge at API call.
- **Delete confirmation**: Use `BeeDialog` with `currentTargetRow` ref pattern for single delete.
- **Batch delete**: Filter deletable/non-deletable rows via `computed`.
- **Styles**: Use project SCSS variables (`$spacing-*`), `flex column` layout, `flex: 1; min-height: 0` for scroll body.

### Step 4: Post-Generation Checklist

After generating the file, verify:

1. All imports are correct (types, API, components, utils)
2. Permission strings match the route meta permissions
3. Route `name` values for `router.push()` exist in the router config
4. API function names match exports in the API file
5. The `clusterId` is correctly injected for K8s resources via `useKubernetesStore`
6. All `v-permission` directives use the correct permission strings
7. Column components (`BeeWorkloadInfoCell`, `BeeStatusCell`, etc.) receive correct props
8. The SCSS uses project variables and follows the flex layout pattern
9. File-level JSDoc comment with `@module` tag is present

## 3. Reference Material

For detailed pattern specifications, column component APIs, and complete code examples, load the
reference file:

```
references/list_page_pattern.md
```
