# Bee Kube List Page 完整模式参考

## 模板结构（三栏弹性布局）

```
BeePage
├── BeeCard（头部：BeePageTitle）
└── BeeCard（主体：flex column）
    ├── .table-toolbar（查询工具栏）
    │   ├── BeeInputSearch（搜索框）
    │   ├── BeeSelect × N（筛选下拉框）
    │   ├── BeeButton：搜索 / 重置
    │   └── BeeButton：新建 / YAML（需权限）
    ├── .table-body（表格区，flex:1 + min-height:0）
    │   └── BeeTable（selectable）
    │       ├── BeeTableColumn + BeeWorkloadInfoCell（首列：资源信息，宽 500）
    │       ├── BeeTableColumn + BeeTableCommonCell（通用列）
    │       ├── BeeTableColumn + BeeStatusCell（状态列）
    │       ├── BeeTableColumn + BeeAuditCell（审计列）
    │       └── BeeTableColumn + BeeActionCell（操作列：fixed="right"）
    └── .table-footer（底部分页）
        ├── 左侧：批量操作按钮区
        └── BeePagination（右侧）
```

## 脚本结构（分区顺序）

```ts
// ========== Composables & Route ==========
// ========== Reactive State ==========
// ========== Options ==========
// ========== Data Loading ==========
// ========== Search & Reset ==========
// ========== Selection ==========
// ========== CRUD: Create/Edit/View ==========
// ========== CRUD: Delete ==========
// ========== Row Actions ==========
// ========== Lifecycle ==========
```

## 关键模式

### 1. 权限缓存

```ts
const perm: Record<string, boolean> = {
  create: hasPermission('kubernetes:workload:deployment:create'),
  edit: hasPermission('kubernetes:workload:deployment:edit'),
  view: hasPermission('kubernetes:workload:deployment:view'),
  delete: hasPermission('kubernetes:workload:deployment:delete'),
  restart: hasPermission('kubernetes:workload:deployment:restart'),
  scale: hasPermission('kubernetes:workload:deployment:scale'),
  import: hasPermission('kubernetes:workload:deployment:import'),
}
```

### 2. 搜索模式

```ts
// searchKey 变量绑定搜索输入框
const searchKey = ref('')

// handleSearch 中将 searchKey 映射到多个字段
function handleSearch() {
  pagination.page = 1
  if (searchKey.value) {
    // 同时搜索 id 和 name
    queryForm.id = searchKey.value
    queryForm.name = searchKey.value
  } else {
    delete queryForm.id
    delete queryForm.name
  }
  loadData()
}
```

### 3. 分页模式

```ts
// pagination (ref) 和 queryForm (reactive) 分离维护
const pagination = ref({ page: 1, pageSize: 10, total: 0 })

const queryForm = reactive<Partial<XxxQueryForm>>({})
// 初始化为空对象，属性通过搜索/重置动态增删

// API 调用时合并参数
async function loadData() {
  loading.value = true
  try {
    const res = await getXxxPage({
      ...queryForm,
      page: pagination.value.page,
      pageSize: pagination.value.pageSize,
    })
    tableData.value = res.list
    pagination.value.total = res.total
  } finally {
    loading.value = false
  }
}
```

### 4. 删除确认模式

```ts
// 单个删除
const deleteDialogVisible = ref(false)
const currentTargetRow = ref<XxxListVo | null>(null)

function handleDelete(row: XxxListVo) {
  currentTargetRow.value = row
  deleteDialogVisible.value = true
}

async function handleConfirmDelete() {
  const id = currentTargetRow.value?.id
  if (!id) return
  try {
    await deleteXxx(id)
    ElMessage.success('删除成功')
    deleteDialogVisible.value = false
    await loadData()
  } catch {
    // error handled by interceptor
  }
}
```

```html
<BeeDialog v-model="deleteDialogVisible" title="确认删除" @confirm="handleConfirmDelete">
  <p>确定要删除 <strong>{{ currentTargetRow?.name }}</strong> 吗？</p>
</BeeDialog>
```

### 5. 批量删除模式

```ts
const deletableRows = computed(() =>
  selectedRows.value.filter(row => row.deletable !== false)
)
const nonDeletableRows = computed(() =>
  selectedRows.value.filter(row => row.deletable === false)
)

async function handleConfirmBatchDelete() {
  const ids = deletableRows.value.map(row => row.id)
  try {
    await deleteXxxs(ids)
    ElMessage.success('批量删除成功')
    batchDeleteDialogVisible.value = false
    handleClearSelection()
    await loadData()
  } catch {
    // error handled by interceptor
  }
}
```

### 6. 操作列模式

```ts
function getActions(row: XxxListVo): ActionItem[] {
  const actions: ActionItem[] = []

  if (perm.view) {
    actions.push({
      label: '详情',
      icon: 'icon-gongzuofuzhai-copy',
      action: () => handleViewDetail(row),
    })
  }

  if (perm.edit && row.editable !== false) {
    actions.push({
      label: '编辑',
      icon: 'icon-bianji',
      action: () => handleEdit(row),
    })
  }

  if (perm.delete && row.deletable !== false) {
    actions.push({
      label: '删除',
      icon: 'icon-shanchu',
      action: () => handleDelete(row),
    })
  }

  return actions
}
```

### 7. 路由跳转模式

```ts
// 创建
function handleCreate() {
  router.push({ name: 'kubernetes:workload:deployment:create' })
}

// 编辑（跳转到创建页，带 id 参数）
function handleEdit(row: XxxListVo) {
  router.push({
    name: 'kubernetes:workload:deployment:create',
    query: { id: row.id },
  })
}

// 查看详情
function handleViewDetail(row: XxxListVo) {
  router.push({
    name: 'kubernetes:workload:deployment:detail',
    params: { name: row.name },
  })
}
```

## 表格列组件 API

### BeeWorkloadInfoCell（首列：资源信息）

| Prop | 类型 | 说明 |
|---|---|---|
| `uid` | `string` | 资源 UID |
| `name` | `string` | 资源名称（可复制） |
| `description` | `string` | 资源描述 |
| `icon` | `string` | 图标资源名，如 `'icon-gongzuofuzai'` |
| `iconSize` | `number` | 图标尺寸，默认 `32` |

### BeePodInfoCell（Pod 首列）

| Prop | 类型 | 说明 |
|---|---|---|
| `uid` | `string` | Pod UID |
| `name` | `string` | Pod 名称 |
| `ip` | `string` | Pod IP |
| `iconSize` | `number` | 图标尺寸 |

### BeeTableCommonCell（通用双行列）

| Prop | 类型 | 说明 |
|---|---|---|
| `text` | `string` | 主文本 |
| `subtext` | `string` | 副文本 |

### BeeStatusCell（状态列）

| Prop | 类型 | 说明 |
|---|---|---|
| `status` | `string \| number` | 状态值 |
| `statusMsg` | `string` | 状态英文标签 |
| `options` | `Array<{label,value,type,color,effect}>` | 状态映射配置 |
| `help` | `string` | 帮助提示文本 |

### BeeAuditCell（审计列）

| Prop | 类型 | 说明 |
|---|---|---|
| `username` | `string` | 用户名 |
| `datetime` | `string` | 时间（格式：YYYY-MM-DD HH:mm:ss） |
| `fieldName` | `string` | 字段名（如 "创建者"） |

### BeeActionCell（操作列）

| Prop | 类型 | 说明 |
|---|---|---|
| `actions` | `ActionItem[]` | 操作项数组 |
| `row` | `any` | 当前行数据 |

ActionItem 接口：

```ts
interface ActionItem {
  label: string        // 操作名称
  icon?: string        // 图标名
  action?: () => void  // 点击回调
  disabled?: boolean   // 是否禁用
}
```

## 状态配置模式

```ts
type StatusOption = { label: string; value: string | number; type: 'success' | 'danger' | 'warning' | 'info'; color?: string; effect?: 'dark' | 'light' | 'plain' }

const STATUS_OPTIONS: StatusOption[] = [
  { label: '运行中', value: 1, type: 'success' },
  { label: '已停止', value: 0, type: 'danger' },
  { label: '更新中', value: 2, type: 'warning' },
]

const STATUS_MAP: Record<number, StatusOption> = {}
STATUS_OPTIONS.forEach(opt => { STATUS_MAP[opt.value] = opt })
```

## SCSS 样式规范

```scss
.page-body {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-height: 0;
  overflow: hidden;

  .table-toolbar {
    display: flex;
    gap: $spacing-8;
    align-items: center;
    padding: $spacing-16 0;

    &__search {
      flex: 1;
      min-width: 0;
    }
  }

  .table-body {
    flex: 1;
    min-height: 0;
  }

  .table-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: $spacing-16 0;

    &__actions {
      display: flex;
      gap: 8px;
      align-items: center;
    }
  }
}
```

## 命名空间选项加载模式

```ts
const namespaceOptions = ref<{ label: string; value: string }[]>([])

async function loadNamespaceOptions() {
  try {
    const res = await getNamespacePage({ page: 1, pageSize: 999 })
    namespaceOptions.value = (res.list || []).map(ns => ({
      label: ns.name,
      value: ns.name,
    }))
  } catch {
    // silently fail - dropdown options are non-critical
  }
}
```

## 完整 imports 示例

```ts
import { createSharedComposable, usePermission } from '@/composables'
import { getXxxPage, deleteXxx, deleteXxxs } from '@/api/kubernetes/workload/deployment'
import type { XxxListVo, XxxQueryForm } from '@/types/kubernetes/workload/deployment'
import type { ActionItem } from '@/components/BeeActionCell/types'
import { useKubernetesStore } from '@/stores'
import { useRoute, useRouter } from 'vue-router'
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
```
